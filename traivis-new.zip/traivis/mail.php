<?php
 

require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


if(isset($_POST['submitbtn'])){
  

    $name = $_POST['usrname'];
    $email= $_POST['email'];
    $address= $_POST['address'];
    $institution = $_POST['institution'];
    $web= $_POST['web'];
    $location= $_POST['address-input'];
     
    
    
    
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com" ;
    $mail->SMTPAuth = "true";
    $mail->SMTPSecure = "tls";
    $mail->Username = "drishya@yarddiant.com";
    $mail->Password = "Yarddiant@123";
    $mail->Subject = "Traivis-Email";
    $mail->setFrom("drishya@yarddiant.com");
    $mail->isHTML(true);
    $mail->Body = "<p>You got an enquiry from  ".$name."</p>
                   <p>Email Id: ".$email."</p>
                   <p>Address: ".$address."</p>
                   <p>Institution Name: ".$institution."</p>
                   <p>Web: ".$web."</p>
                   <p>Location: ".$location."</p>";
    $mail->addAddress("drishya@yarddiant.com");
    if($mail->Send()){
    echo "success";
    }
    }
 
?>